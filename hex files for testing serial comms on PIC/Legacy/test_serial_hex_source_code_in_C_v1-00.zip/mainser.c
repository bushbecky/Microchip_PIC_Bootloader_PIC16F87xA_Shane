#define	PIC_CLK 16000000 //change this to 3.6864, 4, 16 or 20MHz
//this affects mainser.c, for USART speed, and delay.h for delays

/*

Serial port tester

Designed by Shane Tolmie Jun-Dec 99.

Microprocessor: 	Microchip PIC16F87x

Compiled with:		Hitech-C v7.85, MPLAB v5.00.00

Emulated with:		MPLAB ICE 2000 or ICD R4

Documentation:		all references are to PIC16F87x PDF version of Microchip manual

Overall goal: 		serial port tester @ 19200 baud

Project setup under MPLAB:
generate debug info: tick, local optimizations: tick, global optimizations: tick
if using ICD dev board, add -ICD under 'additional options' to make it compatible 
	with the ICD memory requirements

Burning options for 16C76:
Osc: HS, watch dog: ON, power up: ON, code protect: OFF, brown out: ON

Burning options for 16F876/16F877:
Osc: HS, Watchdog: on, power up timer: on, code protect: off, brown out detect: 
on, low voltage program: disabled, data ee protect, off, flash program write, 
enabled, background debug: disabled

Setup options for ICD: MPLAB v4.12.12, board rev R4, dll version 1.2602, firmware version 1.22
CONFIG BITS: Device: 16F877, Osc: HS, Watchdog: On, Power Up Timer: On, Brown 
Out: off, low voltage program: disable, code protect data ee: code pro off,flash 
mem write: no memory written by eecon, code protect: off 
PROGRAM OPTIONS: program mem: tick, config bits:tick, id locations: tick, eeprom 
data: notick, erase all before prog: tick, enable debug mode: tick 
BASE LINE: com2, 57600, all registers, 10Mhz-20Mhz

Add command line switch -ICD under 'additional options' in project setup to make it compatible 
with the ICD memory requirements

Notes: to save memory, you have to comment out a function or else it will be included
even if its never called

*/	

//*****
//include header files 

#include	<pic.h>
#include	<conio.h>
#include	<stdlib.h>
#include 	<stdio.h>
#include	<ctype.h>
#include	"always.h"
#include	"delay.h"
#include	"error.h"
#include	"maths.h"

//****************
//global variables

//*****
//include C files 

#include	"delay.c"
#include	"serial.h"
#include	"serial.c"
//#include	"lowlevel.c"
#include	"error.c"
#include	"maths.c"
#include  "eeprom.c"
#include  "eep_init.c"

#if defined(_16F876) || defined(_16F877) || defined(_16F873) || defined(_16F874) || defined(_16C76)
	__CONFIG(UNPROTECT|BODEN|FOSC1|BKBUG|WRT);
#else
	#error Must be compiled for 16F87x, MPLAB-ICD or 16C76
#endif

//*************
//main function

void main(void)
{
	unsigned char getch_timeout_temp,pass;
  unsigned int i;
	
	OPTION=0xFF;
	CLRWDT();
	serial_setup();

	putlf;
	putlf;
	putlf;
	//could use printf() here but putst saves 1k of rom space
	putst("PICTest (c)2000 Shane Tolmie.  Starting up serial @ 19200 baud ... ");
	putlf;
	putlf;

	//in this particular .hex file, EEPROM all initialized to 0xEE, check that 
	//bootloader has loaded it properly
	putst("Testing EEPROM ... ");
  pass=TRUE;
	for (i=0;i<=0xFF;i++)
	{
		if (eeprom_read((unsigned char)i)!=0xEE)
		{
		  pass=FALSE;
		}
	}
	if (pass==TRUE)
	{
	  putst("[pass]");
	}
	else
	{
	  putst("[FAIL]");
	  putlf;
	  
  	//dump contents of EEPROM to screen
		for (i=0;i<=0xFF;i++)
		{
			putchhex(i);
			putst("=");
			putchhex(eeprom_read((unsigned char)i));
			putst(" - ");
		}
		putlf;
	}
	putlf;
	putlf;

	//go into infinite loop, printing what user types
	putst("Key pressed: ");
	while(1)
	{
		getch_timeout_temp=getch_timeout();
		
		if (getch_timeout_temp==0)
		{
			putst("[timeout] ");	//could use printf here
		}		
		else
		{
			putch(getch_timeout_temp);
			putlf;
		}
	}
}
