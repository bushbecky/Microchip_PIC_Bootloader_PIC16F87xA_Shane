//*****************
//function prototypes

void serial_setup(void);
void putch(unsigned char c);
unsigned char getch(void);
void putst(register const char * str);
unsigned char usart_timeout(void);
void putchdec(unsigned char c);
void putchhex(unsigned char c);
void putinthex(unsigned int c);

#define putlf putch(13);putch(10)														//put line feed
#define putstlf(x) putst(x);putlf														//put string then line feed
#define putchhexlf(x) putchhex(x);putlf											//put char hex then line feed
#define putinthexlf(x) putinthex(x);putlf										//put int hex then line feed
#define putchdeclf(x) putchdec(x);putlf											//put dec then line feed



