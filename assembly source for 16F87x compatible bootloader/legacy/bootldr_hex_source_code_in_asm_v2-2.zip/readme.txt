---------------------------------------------------------------------------------
                  Microchip PIC16F87x Bootloader/Downloader
---------------------------------------------------------------------------------

How to use the bootloader/downloader:

1. Open bootldr.pjt file in the Microchip MPLAB and change the parameters of
   the User setting section (marked '<<<').

2. Recompile bootldr.asm.

3. Program microcontroller with bootldr.hex file. Set your config bits.

4. Recompile your program so it doesn't overwrite the bootloader.
   The bootloader uses 214 bytes at the top of program memory.
   For Hi-Tech C, add -ICD to the PICC options.
   For CCS C, add *only one* of the next two statements, depending on the micro:
     #ORG 0x0F00,0x0FFF //for the 4k 16F873/4
     #ORG 0x1F00,0x1FFF //for the 8k 16F876/7
       void loader() { }
   For assembly, add an equivalent line for reserving these program locations.

   Microchip PIC 16F876/877 memory map with the bootloader installed:

  Address
  0x0000 ----------------------------
         |   Jump to bootloader     |	<--- Bootloader uses 1st 4 program words
  0x0004 |--------------------------|			(0x0000-0x0003)
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |      Program space       |
	 |      available for       |	<--- Available space for user programs
	 |   downloaded programs    |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
  0x1F2A |--------------------------|
	 |  Trap &  Pagesel 0x0000  |	<--- Error Trap and Pagesel instruction
  0x1F2E |--------------------------|
	 |   Jump to user program   |	<--- relocated 1st 4 user program words
  0x1F32 |--------------------------|			(0x1F2E-0x1F31)
	 |                          |
	 |     Bootloader code      |	<--- The bootloader code (0x1F32-0x1FFF)
	 |                          |
  0x1FFF ----------------------------

5. Plug in a serial interface with a MAX232 etc to connect the serial port of
   the computer to pins RX/TX (option RESET/Trigger pin) on microcontroller.
   RC7/RX      - RxD (pin #3, D-SUB-9)
   RC6/TX      - TxD (pin #2, D-SUB-9)
   GND         - GND (pin #5, D-SUB-9)
   RESET       - RTS
   Trigger pin - DTR

6. Run "PIC downloader", and choose baud rate (typ. 19200 baud), COM port,
   write eeprom and the '.hex' file to download.
   Function keys:
   F2 - Search
   F4 - Write
   ESC - Cancel
   F10 - Exit

7. Click "Write" and reset manual PIC, the program is downloaded into
   the PIC micro.

8. After a sucessful download the User program is started.

Notes:
-the bootloader will not use more than 255 words.
-the bootloader/downloader is compatible with HI-TECH's (www.htsoft.com) and
 Shane Tolmie's (www.workingtex.com/htpic) bootloader/downloader.
-the bootloader is rewritten and modified from HI-TECH's C version bootloader
 to assembler.

(c) 2000 Petr Kolomaznik
Email: kolomaznik@ehl.cz
Url:   http://www.ehl.cz/pic
