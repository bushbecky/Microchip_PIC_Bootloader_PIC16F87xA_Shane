/* 16F87x BOOT LOADER
 */

#define DOWNLOAD !RB0
#define DOWNPORT TRISB0
#define OUTPUT 0
#define INPUT 1
