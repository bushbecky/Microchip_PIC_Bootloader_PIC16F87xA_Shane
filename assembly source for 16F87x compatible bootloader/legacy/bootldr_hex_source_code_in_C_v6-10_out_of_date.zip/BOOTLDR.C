/*	16F87x BOOT LOADER

This program based in part on code used with permission 
from HI-TECH Software (www.htsoft.com).

Freely distributable for non-commercial usage, for commercial usage see licence.txt.

Questions and comments to shane@workingtex.com
Want to see 4Mb of Hi-Tech C FAQ and sample source code? http://www.workingtex.com/htpic
(also has tiny device to record keystrokes in hardware on PC)

This version works with 16F876/7, 16Mhz crystal, 19200baud.  Can be compiled
for 16F873/4.

****
Compiling options

Compile with Hi-Tech C v7.83pl2 or above.

Only compile with HPDPIC, not MPLAB.  MPLAB will hash it up unless you do a 
custom compile. If you're debugging, instead of compiling in MPLAB, compile with 
HPDPIC and import the hex file.  Then run with MPLAB-ICD.

*/

#define PIC_CLK 16000000 //speed in Hz, when changing this update delay.h too

/*
*****
see _faq.txt for more info

Burning options for 16F876 are set automatically.

It is possible to link it so it is compatible with MPLAB-ICD, for debugging, 
since ICD uses 0x1f00-0x1fff. To modify so it goes from 0x1e00-0x1eff alter 
#define LoaderStart (see bootldr.c), and modify all 0x1f?? to 0x1e?? for linker 
options under MAKE..LINKER OPTIONS in HPDPIC. There is 5 values to modify. Yes, 
thats 5, one at the start, 4 in the middle.

*/

#include <pic.h>

#if defined(_16F876) || defined(_16F877)
__CONFIG(UNPROTECT | BODEN | CPD | FOSC1 | BKBUG | WRT | 0x400);
#else
	#error Must be compiled for 16F876 or MPLAB-ICD
#endif

#include "bootldr.h"
#include "proto.h"
#include "delay.h"
#include "always.h"

/*
 * Set LoaderStart to the address where the boot loader will start,
 * the other #defines will adjust accordingly.  Adjust linker options too,
 * see "Make..Linker Options", theres 5 values to change.  Yes, theres 5,
 * 1 at the start, and 4 values in the middle. Change 01Fxx for 16F876/7, 
 * 00Fxx for 16F873/4, and 007xx for 16F870/1/2
 *
 */

#define LoaderStart 0x1f00

/*
 * Addresses 0-4 of the downloaded program must be relocated so
 * that they don't overwrite this bootloader startup. UserStart is the
 * address where they will be relocated.
 *
 * LoaderLOW and LoaderHI are the low and high addresses where the
 * bootloader code lives. This is needed so that a downloaded program
 * can't overwrite the bootloader.
 *
 * LoaderID is the address where IDValue is written when a program
 * is downloaded. This is used to determine if a program has been
 * downloaded yet.
 *
 */

#define UserStart	LoaderStart //user addresses 0-4 will go here
#define LoaderSize	0xFF  //compiled size of loader (words)
#define LoaderLOW	(LoaderStart+4) //low address of boot loader
#define LoaderHI	(LoaderStart+LoaderSize)  //high address of boot loader

/*
 * MaxBuf is the maximum buffer size allocated for receiving the
 * incoming data.
 *
 * MaxRetry is the maximum number of attempts made at writing the
 * data.
 *
 */

#define MaxBuf		32	  /* Maximum size of buffer */
#define MaxRetry	2	  /* Maximum number of write retries */


/*
 * Comms setup:
 */

#define BAUD 19200
#define FOSC PIC_CLK
#define NINE_BITS 0	/* Use 9bit communication? FALSE=8bit */
#define DIVIDER ((FOSC/(16UL * BAUD) -1))
#define HIGH_SPEED 1

//you can comment these #assert statements out if you dont want error checking
#if PIC_CLK==3686400 && BAUD==19200
	#assert DIVIDER==11
#elif PIC_CLK==4000000 && BAUD==19200
	#assert DIVIDER==12
#elif PIC_CLK==7372800 && BAUD==19200	
	#assert DIVIDER==23
#elif PIC_CLK==8000000 && BAUD==19200	
	#assert DIVIDER==24
#elif PIC_CLK==9830400 && BAUD==19200	
	#assert DIVIDER==31
#elif PIC_CLK==16000000 && BAUD==19200
	#assert DIVIDER==51
#elif PIC_CLK==20000000 && BAUD==19200
	#assert DIVIDER==64
#else
	//remove this line if you dont want error checking on serial speeds
#endif

/* if DIVIDER is >255 use:
#define DIVIDER ((int)(FOSC/(64UL * BAUD) -1)
#define HIGH_SPEED 0
*/

/*********************************************************************/

unsigned char buff[MaxBuf];
unsigned char count,amount,chk1,chk2,retry;
unsigned address;

void putbyte(unsigned char byte)
{
	//output one byte
	while (!TXIF)	//set when register is empty
	{
		//wait
	}
	TXREG=byte;
}

unsigned char getbyte(void)
{
	unsigned char i;
	unsigned int timeout_int;

	// retrieve one byte with a few seconds timeout
	for (i=48;i!=0;i--)
	{
		//48 * 100ms is about right for a few seconds timeout
		//we are only checking msb of int it is shortened to 3 sec
		timeout_int=timeout_int_us(100000);	//do NOT increase this number - it will overflow the 16-bit integer

		while (byte1(timeout_int)!=0) //only check the msb of the int for being 0, it saves space, see always.h for macro
		{
			CLRWDT();
			timeout_int--;
			if (RCIF)
			{
				return RCREG;
			}
		}
	}
	return 0;
}

void main(void)
{
	unsigned char temp_EEDATH,temp_EEDATA,d;

	//*****
	//this section of codes sets up the watchdog timer
	/*
	set up watchdog timer, p31 for setup, p209 for constant 18ms timeout
	tmr0 pre-scaler assigned to WDT, 1:128 prescaler for 18ms * 128 = min 2.3s timeout
	watchdog timer is cleared getch();

	*/

	OPTION=0B11111111; //this is set to this initially anyway
	CLRWDT();

	/* wait up to 1/4 sec for code to be downloaded, then jump to
	downloaded code */

	//initialize serial
	SPBRG=DIVIDER;
	TXSTA=0B00100100;
	RCSTA=0B10010000;

	//main loader loop
	for (;;)
	{
		switch (getbyte())		//getbyte has a built in 1/2 sec timeout
		{
			case IDENT:		//identify loader
			{
				putbyte(IDACK); //acknowledge
				break;
			}
			case WRITE:		//write & verify data
			{
				address=(unsigned int)(getbyte()<<8); //get write address
				address|=getbyte();
				amount=getbyte(); //assume amount < MaxBuf
				chk2=getbyte(); //get checksum
				count=0;
				chk1=0;
				while (count<amount)
				{ //receive data
					buff[count]=getbyte();
					chk1+=buff[count++];
				}
				if (chk1!=chk2)
				{ //verify check sum
					putbyte(DATA_BAD);
					break;
				}
				//hack
				putbyte(DATA_OK);

				//OK, now we have data in buffer, ready to be written to program or EEPROM

				//*****
				//OK, now write to program memory or EEPROM
				//retry=MaxRetry;
				count=0;
				while (count<amount)
				{
					//make sure it doesn't overwrite the loader,
					//isnt outside the program space 0-0x1FFF or
					//or outside the EEPROM space 0x2100 to 0x21FF
					if (byte1(address)!=0x21)
					{
						if (((address>=(unsigned int)LoaderLOW) && (address<=(unsigned int)LoaderHI))
							|| (byte1(address)>=0x20))
						{
							goto process_next_addr; //ignore, do next address
						}
						EEPGD=1;
					}
					else
					{
						//microchip specifies that EEPROM is from 0x2100 to 0x21FF in .hex file
						//so write to eeprom if it is in that range
						//or write to PROGRAM memory 0x0000 to 0x1FFF if in that range
						EEPGD=0;	
					}

					EEDATH=buff[count];
					temp_EEDATH=EEDATH;

					EEDATA=buff[(unsigned char)(count+1)];
					temp_EEDATA=EEDATA;

					EEADR=(unsigned char)address;

					//move user's start code to a different location
					//if this is EEPROM, high byte is ignored anyway
					if (address<4)
					{
						EEADRH=UserStart>>8;
					}
					else
					{
						EEADRH=address>>8;
					}

					EEIF=0;
					WREN=1;
					EECON2=0x55; //write sequence...
					EECON2=0xaa;
					WR=1;

				  asm("nop");	//for program memory writes (not EEPROM) first instruction after WR=1 is executed normally
				  asm("nop");	//for program memory writes (not EEPROM) this instruction is ignored, processor halts until write finished */

					//if writing to EEPROM area (0x2100 to 0x21FF in hex file), wait for write to complete
					if (byte1(address)==0x21)
					{
						while (!EEIF)
						{
							//wait for write to complete
						}
						EEIF=0;
					}

					//*****
					//verify both EEPROM and program memory
					WREN=0;
					RD=1;

					asm("nop");
					asm("nop");	//wait for read

					if ((EEDATH!=temp_EEDATH) || (EEDATA!=temp_EEDATA))
					{
						//do it over and over again until it passes - not enough room for timeouts
						goto process_same_addr;
					}

					process_next_addr:

					count+=2;
					address++;

					process_same_addr:
					;
				}
				putbyte(WOK); //successful write of buffer
				
				exit_write:
				
				break;
			}

			//***
			//finish downloading
			case DONE:
			{
				putbyte(WOK);
				//1000000/2400*10bits=4166us.  Wait 6ms (generous time for 2400baud) for 
				//byte to vanish, so d=6000/250=24.
				for (d=24;d!=0;d--)
				{
					DelayUs(250);
				}
				//now drop down into the code below; jump to program

				//***
				//if an invalid character is received or getbyte() times
				//  out after 1/2 sec, it jumps to previously downloaded code
			}
			default:
			{
			}
				//reset transmit/receive regs to original
				TXSTA=2;
				RCSTA=0;
				//jump to program
      	#asm
					ljmp UserStart	//what 0x0000 used to jump to in downloaded .hex file
				#endasm
		}
	}
}


