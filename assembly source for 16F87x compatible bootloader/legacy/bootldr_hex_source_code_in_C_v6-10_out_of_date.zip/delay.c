/*

Designed by Shane Tolmie of KeyGhost corporation.  Freely distributable.
Questions and comments to picfaq@keyghost.com
Want to download 4Mb of Hi-Tech C FAQ and sample source code? http://www.keyghost.com/
(also has tiny device to record keystrokes in hardware on PC)

Microprocessor: Microchip PIC16C7x, 16F87x, 12C67x

Compiled with:	Hitech-C v7.85 developed using MPLAB v4.12.12

Overall goal: 	High-level delay Routines

Example C:

#define PIC_CLK 8000000
#include  "delay.h"
#include  "delay.c"

DelayMs(255);
DelayBigMs(0xFFFF);
DelayS(4);

*/

#ifndef __DELAY_C
#define __DELAY_C

void DelayMs(unsigned char cnt)
{
	unsigned char i;
	do
	{
		i=4;
		do
		{
			DelayUs(250);
		} while (--i);
	} while (--cnt);
}

//this copy is for the interrupt function
void DelayMs_interrupt(unsigned char cnt)
{
	unsigned char i;
	do
	{
		i=4;
		do
		{
			DelayUs(250);
		} while (--i);
	} while (--cnt);
}

void DelayBigMs(unsigned int cnt)
{
	unsigned char i;
	do
	{
		i=4;
		do
		{
			DelayUs(250);
			CLRWDT();
		} while (--i);
	} while (--cnt);
}

void DelayS(unsigned char cnt)
{
	unsigned char i;
	do
	{
		i=4;
		do
		{
			DelayMs(250);
			CLRWDT();
		} while (--i);
	} while (--cnt);
}

#endif

